# Sample infomation

# Design

- 2-cut deletion of *Stx2* locus
- Expected deletion size: 727 bases

## test_barcode25.fq.gz

- Three alleles of larger deletions than expected
  - deletion size mapped to deletion alleles
    - allele1: ~260 bp deletion
    - allele2: ~620 bp deletion
    - allele3: ~1800 bp deletion

- 500 reads/allele at 1:1:1 ratio, total 2500 reads

## test_barcode30.fq.gz

- Wild-type control
- total 2000 reads
