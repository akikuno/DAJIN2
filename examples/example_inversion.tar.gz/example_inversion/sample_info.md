# Cables2, artificial plasmid

## Genomic region

- mm39: chr2:179,903,300-179,906,300

## Sequence condition


- Flow Cell: R9.4.1
- Guppy: version 6.1.7+21b93d1 (2022-07-01 basecall)
- minimap2: version 2.24-r1122

## Sample genotype

- barcode47,inversion
- barcode48,wild-type control

## Read numbers

- 1000 reads/sample
