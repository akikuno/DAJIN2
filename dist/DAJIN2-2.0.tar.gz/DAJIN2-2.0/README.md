# DAJIN2

## Example usage
```sh
git clone https://github.com/akikuno/DAJIN2
./DAJIN2/DAJIN -a
```